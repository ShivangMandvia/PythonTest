#6>	Print First 10 numbers using for and while.
a = 10
print("For Loop")
for x in range(1,a+1):
    print(x)
i = 1
print("While Loop")
while(i<=a):
    print(i)
    i+=1