#13> Write a program to convert temperature from Fahrenheit to Celsius.


a=float(input("Enter the temp in farhenheit: "))
c=(5/9)*(a-32)
print("The tenp in celcius is: ",c)