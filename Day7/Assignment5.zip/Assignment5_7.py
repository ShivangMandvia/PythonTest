#7. Write a program that accepts user input as a string and counts how many times ‘a’ got  repeated.

n = input()
print(n.count("a"))