"""
Given code
X = int(input());
while n>=1:
X = X*n
n=n-1
print(x)
"""

#Improved code
X = int(input())#;
#n not declared
n=1 
while n>=1:
    X = X*n
    n=n-1
#Use of lowercase x instead uppercase X 
#print(x)
print(X)

""" 
No of Error - 4 
1.semi-colon in first line
2.n not declared before fourth line
3.Use of lowercase x instead uppercase X in seven

"""
